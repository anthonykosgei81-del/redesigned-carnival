SMARTBIZ PRO — INTERNATIONAL EDITION
Version: 1.0.0 (account and authentication upgrade)

WHAT'S INCLUDED
- Browser-based business management dashboard
- Product and stock management, multi-branch inventory
- Point of sale, sales history and printable receipts
- Customers, suppliers, expenses and reports
- Owner, manager and cashier roles
- Secure owner registration with the required identity/contact fields
- Login using business code + email address OR ID/passport number + password
- Passwords stored using PBKDF2-HMAC-SHA256 with per-user random salts
- Existing databases are upgraded automatically when opened

OWNER REGISTRATION FIELDS
1. Business name
2. First name
3. Last name
4. ID / passport number
5. Email address
6. Phone number (include international country code)
7. Password (minimum 10 characters)
8. Optional first branch name

SIGN-IN
- Business code
- Email address or ID / passport number
- Password

RUN LOCALLY
1. Install Python 3.10 or newer.
2. Extract this ZIP into a folder.
3. Open a terminal in that folder.
4. Run: python server.py
5. Open http://127.0.0.1:8000 in your browser.

DEPLOY TO RENDER
- Create a new Web Service from this folder/repository.
- Use render.yaml (or set start command to: python server.py).
- Keep the persistent disk mounted at /var/data and SMARTBIZ_DATA=/var/data.
- Do not deploy without persistent storage: business databases must survive restarts.

IMPORTANT PRODUCT NOTES
- The included app is the current SmartBiz core release. It includes stock, POS, customers,
  suppliers, expenses, reports and printable receipts.
- M-Pesa payment processing, live barcode-camera scanning, generated PDF receipts,
  offline-first synchronization, automated cloud backups, loyalty rewards and WhatsApp
  messaging are not represented as completed integrations in this release. Those require
  provider credentials, testing and additional implementation before being advertised.
- Before selling commercially, configure HTTPS, backups, privacy/terms pages, support contact,
  production monitoring, and a tested deployment. Never collect real customer data on a demo.
- The ID/passport number is sensitive personal data. Limit access, define retention/deletion
  policies, publish a privacy notice, and meet the laws that apply in each sales territory.

No third-party Python packages are required. The app uses Python's standard library and
SQLite. The Google Fonts stylesheet is optional; the app falls back to system fonts.
